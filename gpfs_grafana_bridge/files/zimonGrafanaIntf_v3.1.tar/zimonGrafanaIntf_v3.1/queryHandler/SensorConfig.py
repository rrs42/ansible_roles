import os
import re
try:
    import SysmonLogger
except Exception:
    pass

mmsdrfsFile = '/var/mmfs/gen/mmsdrfs'
zimonFile = '/opt/IBM/zimon/ZIMonSensors.cfg'
collectorsFile = '/opt/IBM/zimon/ZIMonCollector.cfg'


def readSensorsConfigFromMMSDRFS(logger=None):
    '''
    :return: list of dictionaries with sensorsName as key and the values of the sensors in the mmsdrfs
    '''
    if not logger:
        logger = SysmonLogger.getLogger(__name__)

    if not os.path.isfile(mmsdrfsFile):
        logger.info("MMSDRFS file not found (%s) ", mmsdrfsFile)
        return []

    data=""
    logger.debug("readSensorsConfigFromMMSDRFS attempt to read %s", mmsdrfsFile)
    try:
        with open(mmsdrfsFile) as f:
            data = data.join([line.split(":")[4] for line in f if "PERFMONCFG" in line])
    except (Exception, IOError) as error:
        logger.error("failed trying read %s with reason: %s", mmsdrfsFile, error)
        return []

    sensors = []
    sensorsStr = data[data.find("sensors"):data.find("smbstat")]
    sensorsList = re.findall('(?P<sensor>{.*?})', sensorsStr)
    for sensorString in sensorsList:
        sensorAttr = re.findall(r'(?P<name>\w+) = (?P<value>\"[\S]*\"|\d+)', sensorString)
        d = {}
        for attr in sensorAttr:
            d[attr[0]] = attr[1]
        sensors.append(d)
    return sensors

def readSensorsConfig(logger=None):
    '''
    :return: list of dictionaries with sensorsName as key and the values of the sensors in the ZimonSensors.cfg
    '''
    if not logger:
        logger = SysmonLogger.getLogger(__name__)

    if not os.path.isfile(zimonFile):
        logger.info("ZiMon sensor configuration file not found (%s) ", zimonFile)
        return []

    data=""
    logger.debug("readSensorsConfig attempt to read %s", zimonFile)
    try:
        with open(zimonFile) as myfile:
            data = myfile.read().replace('\n', '')
    except (Exception, IOError) as error:
        logger.error("failed trying read %s with reason: %s", zimonFile, error)
        return []

    sensors = []
    sensorsStr = data[data.find("sensors"):data.find("smbstat")]
    sensorsList = re.findall('(?P<sensor>{.*?})', sensorsStr)
    for sensorString in sensorsList:
        sensorAttr = re.findall(r'(?P<name>\w+) = (?P<value>\"[\S]*\"|\d+)', sensorString)
        d = {}
        for attr in sensorAttr:
            d[attr[0]] = attr[1]
        sensors.append(d)
    return sensors

def getCollectorPorts(logger=None):
    '''
    :return: list of configured query ports found in the ZIMonCollector.cfg
    '''
    if not logger:
        logger = SysmonLogger.getLogger(__name__)

    if not os.path.isfile(collectorsFile):
        raise IOError("ZiMon collector configuration file not found on the localhost")

    queryport = None
    query2port = None

    logger.debug("getCollectorsPorts attempt to read %s", collectorsFile)
    try:
        with open(collectorsFile) as myFile:
            for line in myFile:
                line = line.rstrip()  # remove '\n' at end of line
                if 'queryport' in line:
                    queryport = re.search(r'"(?P<queryport>\d+?)"', line).group('queryport')
                elif 'query2port = ""' in line:
                    query2port = '9094'
                elif 'query2port' in line:
                    query2port = re.search(r'"(?P<query2port>\d+?)"', line).group('query2port')

                if queryport and query2port:
                    return [queryport, query2port]

    except (Exception, IOError) as error:
        logger.error("failed trying read %s with reason: %s", collectorsFile, error)
        return []
    logger.debug("found collector ports: %s", str([queryport, query2port]))
    return [queryport, query2port]
