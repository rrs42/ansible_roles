
README

IBM Spectrum Scale Performance Monitoring Bridge for Grafana v.3.1
Short summary of the changes:

Fixed issues 
		-parsing metric aggregator string fails
		-checking if 

New funcions 
		-set the query interval automatically to the metric data polling interval if the downsampling is disabled explicitly

Source code changes tested with IBM Spectrum Scale 4.2.3 FP8, 5.0.1 FP2, 5.0.2


These are preliminary instructions to install and set-up the
IBM Spectrum Scale Performance bridge connection to the Grafana environment.
Additional information can be found at IBM Spectrum Scale wiki:
https://www.ibm.com/developerworks/community/wikis/home?lang=en#!/wiki/General%20Parallel%20File%20System%20%28GPFS%29/page/IBM%20Spectrum%20Scale%20Performance%20Monitoring%20Bridge

Note: this bridge version could be used for IBM Spectrum Scale devices having mimimum release level 4.2.3 FP8


1. 	Install python (we are using 2.7) 
	-- see instructions on the IBM Spectrum Scale wiki( follow the link above)

2. 	Install cherrypy (min version 3.6.0) via pip or easy_install 
	-- see instructions  on the IBM Spectrum Scale wiki( follow the link above)
	
2.a For https connection you need cherrypy version 4.0.0 (download from: https://pypi.python.org/pypi/CherryPy/4.0.0)
	-- see instructions  on the IBM Spectrum Scale wiki( follow the link above)

2.b If you are using python3 for https connection probably you need another cherrypy version (we have tested python3.4.3 with cherrypy 8.2.0)
	-- see instructions  on the IBM Spectrum Scale wiki( follow the link above)

2.c For python3.6 you need cherrypy version 14.0.1(download from https://pypi.org/project/CherryPy/14.0.1)
    -- see instructions  on the IBM Spectrum Scale wiki( follow the link above)

3. 	Untar zimonGrafanaIntf.tar on the pmcollector node

4. 	Start the IBM Spectrum Scale Performance Monitoring bridge (in the directory zimonGrafanaIntf): 
	Example: python ZIMonGrafanaIntf.py 
	
4.a	For https connection you need to specify listening port 8443 and location path of the privkey.pem and cert.pem file
	Example: python zimonGrafanaIntf.py -k '/root' -p 8443

5. Install grafana (download from http://grafana.org  version 4.2 or higher)

6. Start the grafana server
   service grafana-server start

8. Open grafana at http://<host>:3000 
   Login as admin, pw: admin

9. Define a new data source (Data Sources -> Add New)
   In the panel,
        Name: myBridge
        Type: openTSDB
        Default: selected

        Http settings
			http://<bridge host>:4242 
		or for HTTPS connection:
			https://<bridge host>:8443 
		Access: proxy
		
        OpenTSDB settings
		Version: ==2.3

   	Finally, "Add"

10. Grafana now can talk to Spectrum Scale Performance Monitoring tool via the bridge. Follow the grafana instructions
    to create dashboards. Here is a short outline:

       Dashboards -> Home -> +New
       Green line on the left side <click> -> Add Panel -> Graph
       Click title -> edit
       add metric, bucket_size, tags (filters)

